import tkinter as tk
from tkinter import messagebox

def on_consent():
    if consent_var.get():
        messagebox.showinfo("Consent", "Thank you for your consent!")
        root.destroy()
    else:
        messagebox.showwarning("Consent Required", "You must consent to continue.")

root = tk.Tk()
root.title("Consent Window")
root.geometry("300x150")

consent_var = tk.BooleanVar()
tk.Label(root, text="Please give your consent to continue:").pack(pady=10)
tk.Checkbutton(root, text="I agree to the terms and conditions", variable=consent_var).pack()
tk.Button(root, text="Continue", command=on_consent).pack(pady=10)

root.mainloop()