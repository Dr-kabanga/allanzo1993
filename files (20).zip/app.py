from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def consent():
    if request.method == "POST":
        consent_given = request.form.get("consent") == "on"
        if consent_given:
            # Proceed to main app or whatever is next
            return redirect(url_for("main"))
        else:
            # Return to consent page with error
            return render_template("consent.html", error="You must accept to proceed.")
    return render_template("consent.html", error=None)

@app.route("/main")
def main():
    return "Welcome to the Advanced Security Video Programme!"

if __name__ == "__main__":
    app.run(debug=True)